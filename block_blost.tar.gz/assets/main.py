import pygame
from pygame.locals import *
import random
import asyncio

# Remove or comment out this function - you won't need it
# async def wait_ms(ms):
#     await asyncio.sleep(ms / 1000)

pygame.init()

global font
font = pygame.font.Font(None, 200)
font2 = pygame.font.Font(None, 50)
fenetre = pygame.display.set_mode((900, 600), pygame.RESIZABLE)

cell_size = 60
grid = [[None for _ in range(8)] for _ in range(8)]
wich_block = -1
global score
score = 0
line_cleared = False
konami_seq = [K_UP, K_UP, K_DOWN, K_DOWN, K_LEFT, K_RIGHT, K_LEFT, K_RIGHT, K_b, K_a]
konami_index = 0
konami = False
global color
color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

clear_queue = []
last_clear_time = 0
CLEAR_DELAY = 50

# Mouse/touch drag variables
dragging = False
drag_block = -1
drag_offset = (0, 0)

# le gui et tt le bazar

smallfont = pygame.font.SysFont('Corbel', 35)

text1 = smallfont.render('start', True, color)
text2 = smallfont.render('quit', True, color)
text3 = smallfont.render('credit', True, color)
text4 = smallfont.render('how to play', True, color)
start = False
width = fenetre.get_width()
height = fenetre.get_height()

# ADD THESE VARIABLES
credit_start_time = 0
tutorial_start_time = 0
game_over_start_time = 0


def collect_full_line_cells(grid):
    global line_cleared
    size = len(grid)
    full_rows = [r for r in range(size) if all(grid[r][c] is not None for c in range(size))]
    full_cols = [c for c in range(size) if all(grid[r][c] is not None for r in range(size))]

    cells = []
    for r in full_rows:
        for c in range(size):
            cells.append((r, c))
    for c in full_cols:
        for r in range(size):
            cells.append((r, c))

    return cells


def place_shape(shape, base_r, base_c, grid, color):
    for dr, dc in shape:
        r = base_r + dr
        c = base_c + dc
        if 0 <= r < 8 and 0 <= c < 8:
            grid[r][c] = color


def can_place(shape, base_r, base_c, grid):
    for dr, dc in shape:
        r = base_r + dr
        c = base_c + dc

        if r < 0 or r >= 8:
            return False
        if c < 0 or c >= 8:
            return False
        if grid[r][c] is not None:
            return False

    return True


def has_any_move(shapes, grid):
    for shape in shapes:
        if not shape:
            continue
        for r in range(8):
            for c in range(8):
                if can_place(shape, r, c, grid):
                    return True
    return False


def blocks(grid):
    shapes = [
        [(0, 1), (1, 0), (1, 1), (1, 2)],
        [(0, 0), (0, 1), (0, 2), (1, 1)],
        [(0, 0), (0, 1), (1, 1), (0, 2)],
        [(0, 1), (1, 0), (1, 1), (2, 1)],
        [(0, 0), (0, 1), (1, 1), (1, 2)],
        [(1, 0), (1, 1), (0, 1), (0, 2)],
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(1, 0), (1, 1), (0, 1), (0, 2)],
        [(0, 0), (1, 0), (2, 0), (2, 1)],
        [(0, 1), (1, 1), (2, 1), (2, 0)],
        [(0, 0), (0, 1), (0, 2), (1, 2)],
        [(0, 0), (1, 0), (0, 1), (0, 2)],
        [(0, 0), (1, 0), (2, 0), (2, 1), (2, 2)],
        [(0, 2), (1, 2), (2, 2), (2, 1), (2, 0)],
        [(0, 0), (0, 1), (0, 2), (1, 2), (2, 2)],
        [(0, 0), (0, 1), (0, 2), (1, 0), (2, 0)],
        [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)],
        [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0)],
        [(0, 0), (0, 1), (0, 2), (0, 2), (0, 3), (0, 4)],
        [(0, 0), (1, 0), (2, 0), (3, 0)],
        [(0, 0), (0, 1), (0, 2), (0, 2), (0, 3)],
    ]
    global current_blocks, block_positions, block_colors
    current_blocks = random.sample(shapes, 3)
    block_colors = [
        (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        for _ in range(3)
    ]
    block_positions = [(1, 9), (4, 9), (7, 9)]
    return current_blocks


# ADD THIS ASYNC WRAPPER
async def main():
    global start, wich_block, score, konami_index, konami, grid
    global credit_start_time, tutorial_start_time, game_over_start_time
    global clear_queue, last_clear_time, line_cleared
    global current_blocks, block_positions, block_colors
    global dragging, drag_block, drag_offset
    continuer = True

    blocks(grid)
    while continuer:
        # Handle credit/tutorial/game over timeouts
        now = pygame.time.get_ticks()
        if credit_start_time > 0 and now - credit_start_time >= 5000:
            credit_start_time = 0
            start = True
        if tutorial_start_time > 0 and now - tutorial_start_time >= 5000:
            tutorial_start_time = 0
            start = True
        if game_over_start_time > 0 and now - game_over_start_time >= 5000:
            game_over_start_time = 0
            grid = [[None for _ in range(8)] for _ in range(8)]
            score = 0
            wich_block = -1
            konami_index = 0
            konami = False
            dragging = False
            drag_block = -1
            blocks(grid)
            start = False

        for event in pygame.event.get():

            if start == False:
                if event.type == pygame.MOUSEBUTTONDOWN:

                    # if the mouse is clicked on the
                    # button the game is terminated
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        mouse = pygame.mouse.get_pos()  # MOVE THIS HERE
                        if start_rect.collidepoint(mouse):
                            start = True
                        elif quit_rect.collidepoint(mouse):
                            continuer = False  # CHANGED from pygame.quit()
                        elif credit_rect.collidepoint(mouse):
                            credit_start_time = pygame.time.get_ticks()  # CHANGED
                        elif explain_rect.collidepoint(mouse):
                            tutorial_start_time = pygame.time.get_ticks()  # CHANGED
            if start == True:
                # --- MOUSE/TOUCH: select and drag a shape ---
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    clicked_col = mx // cell_size
                    clicked_row = my // cell_size

                    # Check if clicking on one of the 3 preview shapes to select it
                    found = -1
                    for i, shape in enumerate(current_blocks):
                        if not shape:
                            continue
                        base_r, base_c = block_positions[i]
                        for dr, dc in shape:
                            r = base_r + dr
                            c = base_c + dc
                            if clicked_row == r and clicked_col == c:
                                found = i
                                break
                        if found != -1:
                            break

                    if found != -1:
                        # Start dragging this shape
                        wich_block = found
                        dragging = True
                        drag_block = found
                        base_r, base_c = block_positions[found]
                        drag_offset = (my - base_r * cell_size, mx - base_c * cell_size)
                    elif wich_block != -1 and 0 <= clicked_row < 8 and 0 <= clicked_col < 8:
                        # If a block is already selected, click on grid to place it
                        shape = current_blocks[wich_block]
                        # Center shape on clicked cell
                        if shape:
                            min_dr = min(dr for dr, dc in shape)
                            min_dc = min(dc for dr, dc in shape)
                            max_dr = max(dr for dr, dc in shape)
                            max_dc = max(dc for dr, dc in shape)
                            center_dr = (min_dr + max_dr) // 2
                            center_dc = (min_dc + max_dc) // 2
                            base_r = clicked_row - center_dr
                            base_c = clicked_col - center_dc
                            block_positions[wich_block] = (base_r, base_c)
                            clr = block_colors[wich_block]
                            if can_place(shape, base_r, base_c, grid):
                                place_shape(shape, base_r, base_c, grid, clr)
                                current_blocks[wich_block] = []
                                wich_block = -1
                                score += 5
                    elif konami and 0 <= clicked_row < 8 and 0 <= clicked_col < 8:
                        # Konami: toggle cell on grid
                        if grid[clicked_row][clicked_col] == color:
                            grid[clicked_row][clicked_col] = None
                        else:
                            grid[clicked_row][clicked_col] = color

                if event.type == pygame.MOUSEMOTION and dragging and drag_block != -1:
                    mx, my = event.pos
                    new_r = (my - drag_offset[0]) // cell_size
                    new_c = (mx - drag_offset[1]) // cell_size
                    block_positions[drag_block] = (new_r, new_c)

                if event.type == pygame.MOUSEBUTTONUP and dragging and drag_block != -1:
                    # Drop: try to place on the grid
                    shape = current_blocks[drag_block]
                    base_r, base_c = block_positions[drag_block]
                    clr = block_colors[drag_block]
                    if shape and can_place(shape, base_r, base_c, grid):
                        place_shape(shape, base_r, base_c, grid, clr)
                        current_blocks[drag_block] = []
                        wich_block = -1
                        score += 5
                    dragging = False
                    drag_block = -1

                if current_blocks == [[], [], []]:
                    blocks(grid)

                # --- KEYBOARD CONTROLS (existing) ---
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1:
                        wich_block = 0
                    elif event.key == pygame.K_2:
                        wich_block = 1
                    elif event.key == pygame.K_3:
                        wich_block = 2
                    if wich_block != -1 and (event.key == pygame.K_UP or event.key == pygame.K_z):
                        r, c = block_positions[wich_block]
                        block_positions[wich_block] = (r - 1, c)

                    if wich_block != -1 and (event.key == pygame.K_DOWN or event.key == pygame.K_s):
                        r, c = block_positions[wich_block]
                        block_positions[wich_block] = (r + 1, c)

                    if wich_block != -1 and (event.key == pygame.K_LEFT or event.key == pygame.K_q):
                        r, c = block_positions[wich_block]
                        block_positions[wich_block] = (r, c - 1)

                    if wich_block != -1 and (event.key == pygame.K_RIGHT or event.key == pygame.K_d):
                        r, c = block_positions[wich_block]
                        block_positions[wich_block] = (r, c + 1)

                    if event.key == pygame.K_RETURN and wich_block != -1:
                        shape = current_blocks[wich_block]
                        base_r, base_c = block_positions[wich_block]
                        blk_color = block_colors[wich_block]
                        if can_place(shape, base_r, base_c, grid):
                            place_shape(shape, base_r, base_c, grid, blk_color)
                            current_blocks[wich_block] = []
                            wich_block = -1
                            score += 5
                    if current_blocks == [[], [], []]:
                        blocks(grid)
                    if event.key == konami_seq[konami_index]:
                        konami_index += 1
                        if konami_index == len(konami_seq) and konami == False:
                            konami = True
                            konami_index = 0
                        if konami_index == len(konami_seq) and konami == True:
                            konami = False
                            konami_index = 0
                    else:
                        konami_index = 0

            if event.type == QUIT:
                continuer = False

            if line_cleared:
                score += 20
                line_cleared = False

        # DISPLAY LOGIC
        if credit_start_time > 0:
            fenetre.fill((0, 0, 0))
            fenetre.blit(smallfont.render("un grand merci à", True, "blue"), (width // 2 - 100, height // 2))
            fenetre.blit(smallfont.render("toute ma classe", True, "blue"), (width // 2 - 100, height // 2 + 30))
            fenetre.blit(smallfont.render("à tout ceux qui m'ont aidé", True, "blue"),
                         (width // 2 - 100, height // 2 + 60))
            fenetre.blit(smallfont.render("a mes professeurs", True, "blue"), (width // 2 - 100, height // 2 + 90))
            fenetre.blit(smallfont.render("code de Hugo LAFABRIE", True, "blue"), (width // 2 - 100, height // 2 + 120))
        elif tutorial_start_time > 0:
            fenetre.fill((0, 0, 0))
            fenetre.blit(smallfont.render("click a shape to select it, then", True, "white"),
                         (width // 2 - 250, height // 2))
            fenetre.blit(smallfont.render("drag it onto the grid to place it", True, "white"),
                         (width // 2 - 250, height // 2 + 30))
            fenetre.blit(smallfont.render("or click on the grid to drop it there", True, "white"),
                         (width // 2 - 250, height // 2 + 60))
            fenetre.blit(smallfont.render("keyboard: 1/2/3 + ZQSD/arrows + Enter", True, "white"),
                         (width // 2 - 250, height // 2 + 90))
        elif start == False:
            fenetre.fill((40, 40, 40))  # clear screen (black)

            mouse = pygame.mouse.get_pos()
            width, height = fenetre.get_size()

            start_rect = text1.get_rect(center=(width // 2, height // 2))
            quit_rect = text2.get_rect(center=(width // 2, height // 2 + 40))
            credit_rect = text3.get_rect(center=(width // 2, height // 2 + 80))
            explain_rect = text4.get_rect(center=(width // 2, height // 2 + 120))
            fenetre.blit(text1, start_rect)
            fenetre.blit(text2, quit_rect)
            fenetre.blit(text3, credit_rect)
            fenetre.blit(text4, explain_rect)
        else:  # start == True
            if not clear_queue:
                clear_queue = collect_full_line_cells(grid)
                if clear_queue:
                    score += 20
            now = pygame.time.get_ticks()
            if clear_queue and now - last_clear_time >= CLEAR_DELAY:
                r, c = clear_queue.pop(0)
                grid[r][c] = None
                last_clear_time = now

            fenetre.fill((30, 30, 30))
            for row in range(8):
                for col in range(8):
                    rect = pygame.Rect(col * cell_size, row * cell_size, cell_size, cell_size)
                    if grid[row][col] is not None:
                        pygame.draw.rect(fenetre, grid[row][col], rect)
                    else:
                        pygame.draw.rect(fenetre, (50, 50, 50), rect)
                    pygame.draw.rect(fenetre, (200, 200, 200), rect, 1)

            for i, shape in enumerate(current_blocks):
                base_r, base_c = block_positions[i]
                for dr, dc in shape:
                    r = base_r + dr
                    c = base_c + dc
                    rect = pygame.Rect(c * cell_size, r * cell_size, cell_size, cell_size)
                    pygame.draw.rect(fenetre, block_colors[i], rect)
                    pygame.draw.rect(fenetre, (200, 200, 200), rect, 1)
            if not has_any_move(current_blocks, grid) and game_over_start_time == 0:
                fenetre.blit(font.render("you Lost", True, "Red"), (100, 250))
                game_over_start_time = pygame.time.get_ticks()  # CHANGED

        fenetre.blit(font2.render(f"tu es a {str(score)}", True, '#55ff55'), (550, 0))

        pygame.display.update()
        await asyncio.sleep(0)  # CRITICAL LINE FOR PYGBAG

    pygame.quit()


# RUN THE ASYNC MAIN
asyncio.run(main())
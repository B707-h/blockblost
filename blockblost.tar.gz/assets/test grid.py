import pygame
from pygame.locals import *
import time

pygame.init()
pygame.key.set_repeat(500, 100)


fenetre = pygame.display.set_mode((640, 480))

cell_size = 60
grid = [["" for _ in range(8)] for _ in range(8)]

def clear_full_lines(grid):
    size = len(grid)
    full_rows = [r for r in range(size) if all(grid[r][c] == "x" for c in range(size))]
    full_cols = [c for c in range(size) if all(grid[r][c] == "x" for r in range(size))]
    for r in full_rows:
        for c in range(size):
            grid[r][c] = ""
    for c in full_cols:
        for r in range(size):
            grid[r][c] = ""

continuer = True
while continuer:
    for event in pygame.event.get():
        if event.type == QUIT:
            continuer = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()
            col = mx // cell_size
            row = my // cell_size
            if 0 <= row < 8 and 0 <= col < 8:
                if grid[row][col] == "x":
                    grid[row][col] = ""
                else:
                    grid[row][col] = "x"
            clear_full_lines(grid)

    fenetre.fill((0, 0, 0))  # clear screen (black)


    for row in range(8):
        for col in range(8):
            rect = pygame.Rect(col * cell_size, row * cell_size, cell_size, cell_size)
            if grid[row][col] == "x":
                pygame.draw.rect(fenetre, (0, 255, 0), rect)
            if grid[row][col] == "":
                pygame.draw.rect(fenetre, (50, 50, 50), rect)
            pygame.draw.rect(fenetre, (200, 200, 200), rect, 1)


    pygame.display.update()



pygame.quit()